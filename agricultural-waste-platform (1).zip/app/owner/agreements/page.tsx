"use client"

import { useState } from "react"
import { motion, AnimatePresence } from "framer-motion"
import {
  FileCheck,
  Clock,
  CheckCircle2,
  Package,
  Users,
  MapPin,
  Calendar,
  Phone,
  User,
  DollarSign,
  Truck,
  X,
  AlertCircle,
  MessageSquare,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { useLanguage } from "@/lib/language-context"

type Agreement = {
  id: number
  farmerName: string
  farmerPhone: string
  location: string
  wasteType: string
  declaredQuantity: number
  startDate: string
  endDate: string
  status: "pending" | "approved" | "rejected"
  submittedAt: string
}

export default function OwnerAgreementsPage() {
  const { t } = useLanguage()
  const [selectedAgreement, setSelectedAgreement] = useState<Agreement | null>(null)
  const [filter, setFilter] = useState<"all" | "pending" | "approved" | "rejected">("all")
  const [showRejectDialog, setShowRejectDialog] = useState(false)
  const [rejectReason, setRejectReason] = useState("")

  const [agreements, setAgreements] = useState<Agreement[]>([
    {
      id: 1,
      farmerName: "Kamal Perera",
      farmerPhone: "+94 77 123 4567",
      location: "Anuradhapura, NCP",
      wasteType: "Paddy Straw (Piduru)",
      declaredQuantity: 500,
      startDate: "2026-02-01",
      endDate: "2026-04-30",
      status: "pending",
      submittedAt: "2026-01-28",
    },
    {
      id: 2,
      farmerName: "Sunil Fernando",
      farmerPhone: "+94 71 987 6543",
      location: "Polonnaruwa, NCP",
      wasteType: "Rice Husk",
      declaredQuantity: 200,
      startDate: "2026-02-15",
      endDate: "2026-05-15",
      status: "pending",
      submittedAt: "2026-01-27",
    },
    {
      id: 3,
      farmerName: "Nimal Silva",
      farmerPhone: "+94 76 555 1234",
      location: "Kurunegala, NWP",
      wasteType: "Coconut Shells",
      declaredQuantity: 150,
      startDate: "2026-02-01",
      endDate: "2026-03-31",
      status: "approved",
      submittedAt: "2026-01-20",
    },
    {
      id: 4,
      farmerName: "Ranjith Bandara",
      farmerPhone: "+94 78 222 3333",
      location: "Ampara, EP",
      wasteType: "Paddy Straw (Piduru)",
      declaredQuantity: 750,
      startDate: "2026-03-01",
      endDate: "2026-06-30",
      status: "pending",
      submittedAt: "2026-01-29",
    },
  ])

  const stats = [
    {
      title: t("pendingAgreements"),
      value: agreements.filter((a) => a.status === "pending").length,
      icon: Clock,
      color: "accent",
    },
    {
      title: t("activeAgreements"),
      value: agreements.filter((a) => a.status === "approved").length,
      icon: CheckCircle2,
      color: "primary",
    },
    {
      title: t("totalDeclaredWaste"),
      value: `${agreements.reduce((sum, a) => sum + a.declaredQuantity, 0)} kg`,
      icon: Package,
      color: "secondary",
    },
    {
      title: t("farmersAwaitingApproval"),
      value: agreements.filter((a) => a.status === "pending").length,
      icon: Users,
      color: "primary",
    },
  ]

  const filteredAgreements =
    filter === "all" ? agreements : agreements.filter((a) => a.status === filter)

  const handleApprove = (id: number) => {
    setAgreements((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: "approved" as const } : a))
    )
    setSelectedAgreement(null)
  }

  const handleReject = (id: number) => {
    setAgreements((prev) =>
      prev.map((a) => (a.id === id ? { ...a, status: "rejected" as const } : a))
    )
    setShowRejectDialog(false)
    setSelectedAgreement(null)
    setRejectReason("")
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-accent/20 text-accent-foreground border-accent/30">
            <Clock className="w-3 h-3 mr-1" />
            {t("pending")}
          </Badge>
        )
      case "approved":
        return (
          <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            {t("active")}
          </Badge>
        )
      case "rejected":
        return (
          <Badge variant="outline" className="bg-destructive/10 text-destructive border-destructive/30">
            <X className="w-3 h-3 mr-1" />
            {t("rejected")}
          </Badge>
        )
      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <motion.div
            key={stat.title}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="p-5">
              <div className="flex items-center gap-4">
                <div
                  className={`w-12 h-12 rounded-2xl flex items-center justify-center ${
                    stat.color === "primary"
                      ? "bg-primary/10"
                      : stat.color === "accent"
                        ? "bg-accent/20"
                        : "bg-secondary"
                  }`}
                >
                  <stat.icon
                    className={`w-6 h-6 ${
                      stat.color === "primary"
                        ? "text-primary"
                        : stat.color === "accent"
                          ? "text-accent-foreground"
                          : "text-primary"
                    }`}
                  />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">{stat.title}</p>
                  <p className="text-2xl font-bold text-foreground">{stat.value}</p>
                </div>
              </div>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 flex-wrap">
        {(["all", "pending", "approved", "rejected"] as const).map((f) => (
          <Button
            key={f}
            variant={filter === f ? "default" : "outline"}
            size="sm"
            onClick={() => setFilter(f)}
            className={filter === f ? "bg-primary text-primary-foreground" : "bg-transparent"}
          >
            {f === "all"
              ? "All"
              : f === "pending"
                ? t("pending")
                : f === "approved"
                  ? t("active")
                  : t("rejected")}
            {f !== "all" && (
              <span className="ml-1.5 text-xs">
                ({agreements.filter((a) => a.status === f).length})
              </span>
            )}
          </Button>
        ))}
      </div>

      {/* Agreements Table */}
      <Card className="overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted/50 border-b border-border">
              <tr>
                <th className="text-left p-4 font-medium text-muted-foreground text-sm">
                  Farmer
                </th>
                <th className="text-left p-4 font-medium text-muted-foreground text-sm">
                  Waste Type
                </th>
                <th className="text-left p-4 font-medium text-muted-foreground text-sm">
                  Quantity
                </th>
                <th className="text-left p-4 font-medium text-muted-foreground text-sm">
                  Location
                </th>
                <th className="text-left p-4 font-medium text-muted-foreground text-sm">
                  Status
                </th>
                <th className="text-right p-4 font-medium text-muted-foreground text-sm">
                  Action
                </th>
              </tr>
            </thead>
            <tbody>
              {filteredAgreements.map((agreement, index) => (
                <motion.tr
                  key={agreement.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: index * 0.05 }}
                  className="border-b border-border last:border-0 hover:bg-muted/30 transition-colors"
                >
                  <td className="p-4">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 bg-primary/10 rounded-full flex items-center justify-center">
                        <User className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="font-medium text-foreground">{agreement.farmerName}</p>
                        <p className="text-xs text-muted-foreground">{agreement.submittedAt}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="text-foreground">{agreement.wasteType}</span>
                  </td>
                  <td className="p-4">
                    <span className="font-medium text-foreground">
                      {agreement.declaredQuantity} kg
                    </span>
                  </td>
                  <td className="p-4">
                    <span className="text-muted-foreground">{agreement.location}</span>
                  </td>
                  <td className="p-4">{getStatusBadge(agreement.status)}</td>
                  <td className="p-4 text-right">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setSelectedAgreement(agreement)}
                      className="bg-transparent"
                    >
                      {t("reviewAgreement")}
                    </Button>
                  </td>
                </motion.tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredAgreements.length === 0 && (
          <div className="p-12 text-center">
            <FileCheck className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">No agreements found</p>
          </div>
        )}
      </Card>

      {/* Review Panel (Dialog) */}
      <Dialog open={!!selectedAgreement} onOpenChange={() => setSelectedAgreement(null)}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Review Agreement</DialogTitle>
          </DialogHeader>

          {selectedAgreement && (
            <div className="space-y-6 mt-4">
              {/* Farmer Details */}
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  {t("farmerDetails")}
                </h3>
                <div className="grid gap-3">
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <User className="w-4 h-4 text-primary" />
                    <span className="text-foreground">{selectedAgreement.farmerName}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Phone className="w-4 h-4 text-primary" />
                    <span className="text-foreground">{selectedAgreement.farmerPhone}</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <MapPin className="w-4 h-4 text-primary" />
                    <span className="text-foreground">{selectedAgreement.location}</span>
                  </div>
                </div>
              </div>

              {/* Waste Declaration */}
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  {t("wasteDeclaration")}
                </h3>
                <div className="grid gap-3">
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Package className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">{t("wasteType")}</p>
                      <p className="font-medium text-foreground">{selectedAgreement.wasteType}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Package className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">{t("declaredQuantity")}</p>
                      <p className="font-medium text-foreground">
                        {selectedAgreement.declaredQuantity} kg
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
                    <Calendar className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">{t("availabilityPeriod")}</p>
                      <p className="font-medium text-foreground">
                        {selectedAgreement.startDate} - {selectedAgreement.endDate}
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Platform Conditions */}
              <div className="space-y-3">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wide">
                  {t("platformConditions")}
                </h3>
                <div className="grid sm:grid-cols-2 gap-3">
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-muted/50">
                    <DollarSign className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">{t("pricePerKg")}</p>
                      <p className="text-sm font-medium text-foreground">Rs. 5.00 - 8.00</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 p-3 rounded-xl bg-muted/50">
                    <Truck className="w-4 h-4 text-primary" />
                    <div>
                      <p className="text-xs text-muted-foreground">Collection</p>
                      <p className="text-sm font-medium text-foreground">Platform Team</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              {selectedAgreement.status === "pending" && (
                <div className="flex gap-3 pt-4 border-t border-border">
                  <Button
                    onClick={() => handleApprove(selectedAgreement.id)}
                    className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    <CheckCircle2 className="w-4 h-4 mr-2" />
                    {t("approveAgreement")}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => setShowRejectDialog(true)}
                    className="flex-1 text-destructive border-destructive/30 hover:bg-destructive/10 bg-transparent"
                  >
                    <X className="w-4 h-4 mr-2" />
                    {t("rejectAgreement")}
                  </Button>
                </div>
              )}

              {selectedAgreement.status !== "pending" && (
                <div className="pt-4 border-t border-border">
                  <div className="flex items-center gap-2">
                    {selectedAgreement.status === "approved" ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-primary" />
                        <span className="font-medium text-primary">Agreement Approved</span>
                      </>
                    ) : (
                      <>
                        <X className="w-5 h-5 text-destructive" />
                        <span className="font-medium text-destructive">Agreement Rejected</span>
                      </>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reject Dialog */}
      <Dialog open={showRejectDialog} onOpenChange={setShowRejectDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-destructive" />
              Reject Agreement
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                Reason for rejection (optional)
              </label>
              <Textarea
                placeholder="Enter reason..."
                value={rejectReason}
                onChange={(e) => setRejectReason(e.target.value)}
                className="resize-none"
                rows={3}
              />
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowRejectDialog(false)}
                className="flex-1 bg-transparent"
              >
                Cancel
              </Button>
              <Button
                onClick={() => selectedAgreement && handleReject(selectedAgreement.id)}
                className="flex-1 bg-destructive text-destructive-foreground hover:bg-destructive/90"
              >
                Confirm Rejection
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
